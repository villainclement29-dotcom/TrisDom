import { FlowCanvas } from '@agentix/canvas'
import {
  ReactFlow,
  Background,
  Controls,
  useNodesState,
  useEdgesState,
  addEdge,
  getIncomers,
  getOutgoers,
  getConnectedEdges,
} from '@xyflow/react'
import '@xyflow/react/dist/style.css'
import { Flex, Box } from '@radix-ui/themes'
import { ContentContainer } from '@agentix/content-box'
import { AIContainer } from '@agentix/ai'
import { Resizable } from 're-resizable'
export function Home() {
  return (
    <div style={{ height: '100%', width: '100%' }}>
      <Flex
        justify={'between'}
        gap={'3'}>
        <AIContainer/>
        <FlowCanvas />
        <ContentContainer />
      </Flex>
    </div>
  )
}
