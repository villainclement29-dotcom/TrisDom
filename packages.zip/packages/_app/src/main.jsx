import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { Home } from './home/Home'
import { Theme } from '@radix-ui/themes'

import '@radix-ui/themes/styles.css'
import './index.css'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <Theme>
     <Home />
    </Theme>
  </StrictMode>,
)
