import { Box } from '@radix-ui/themes'
import { Resizable } from 're-resizable'

export function ContentContainer() {
  return (
    <Resizable
      defaultSize={{
        width: 320,
        height: 200,
      }}
      style={{ border : '1px solid black'}}>
      <Box>
        <div>ContentContainer</div>
      </Box>
    </Resizable>
  )
}
