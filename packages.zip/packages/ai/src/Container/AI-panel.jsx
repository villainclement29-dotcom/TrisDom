
import { Resizable } from 're-resizable'
import { Chat } from '../chat/Chat'
export function AIContainer() {
  return (
    <Resizable
    style = {{ 
        border : '1px solid black',
        height: '100%',
    }}
      defaultSize={{
        width: 320,
        height: '100%',
      }}>
    <Chat />
    </Resizable>
  )
}
