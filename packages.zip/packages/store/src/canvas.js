import { atom } from 'nanostores'
import { initialEdges, initialNodes } from './initialData'
import { getLayoutedElements } from '@agentix/util'

// Processed nodes with new positions
const { nodes, edges } = getLayoutedElements(initialNodes, initialEdges)

export const $nodes = atom(nodes)
export const $edges = atom(edges)

export const $setNodes = (nodes) => {
  $nodes.set(nodes)
}

export const $setEdges = (edges) => {
  $edges.set(edges)
}

export const $addNode = (node) => {
  const newNodes = [...$nodes.get(), node]
  $nodes.set(newNodes)
}

export const $addEdge = (edge) => {
  const newEdges = [...$edges.get(), edge]

  // Processed nodes with new positions
  const { nodes, edges } = getLayoutedElements($nodes.get(), newEdges)

  $nodes.set(nodes)
  $edges.set(edges)
}
