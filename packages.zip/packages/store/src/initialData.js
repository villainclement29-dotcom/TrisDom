import { NODE_TOOLBAR } from '@agentix/util'

const position = { x: 0, y: 0 }
const edgeType = 'smoothstep'

export const initialNodes = [
  {
    id: '1',
    type: 'input',
    data: { label: 'input' },
    position,
    type: NODE_TOOLBAR,
  },
  {
    id: '2',
    data: { label: 'node 2' },
    position,
    type: NODE_TOOLBAR,
  },
  {
    id: '2a',
    data: { label: 'node 2a' },
    position,
    type: NODE_TOOLBAR,
  },
  {
    id: '2b',
    data: { label: 'node 2b' },
    position,
    type: NODE_TOOLBAR,
  },
  {
    id: '2c',
    data: { label: 'node 2c' },
    position,
    type: NODE_TOOLBAR,
  },
  {
    id: '2d',
    data: { label: 'node 2d' },
    position,
    type: NODE_TOOLBAR,
  },
  {
    id: '3',
    data: { label: 'node 3' },
    position,
    type: NODE_TOOLBAR,
  },
  {
    id: '4',
    data: { label: 'node 4' },
    position,
    type: NODE_TOOLBAR,
  },
  {
    id: '5',
    data: { label: 'node 5' },
    position,
    type: NODE_TOOLBAR,
  },
  {
    id: '6',
    type: 'output',
    data: { label: 'output' },
    position,
    type: NODE_TOOLBAR,
  },
  { id: '7', type: 'output', data: { label: 'output' }, type: NODE_TOOLBAR, position },
]

export const initialEdges = [
  { id: 'e12', source: '1', target: '2', type: edgeType, animated: true },
  { id: 'e13', source: '1', target: '3', type: edgeType, animated: true },
  { id: 'e22a', source: '2', target: '2a', type: edgeType, animated: true },
  { id: 'e22b', source: '2', target: '2b', type: edgeType, animated: true },
  { id: 'e22c', source: '2', target: '2c', type: edgeType, animated: true },
  { id: 'e2c2d', source: '2c', target: '2d', type: edgeType, animated: true },
  { id: 'e45', source: '4', target: '5', type: edgeType, animated: true },
  { id: 'e56', source: '5', target: '6', type: edgeType, animated: true },
  { id: 'e57', source: '5', target: '7', type: edgeType, animated: true },
]
