import { $addEdge, $addNode } from '@agentix/store'
import { getID, NODE_TOOLBAR, styled } from '@agentix/util'
import { Box } from '@radix-ui/themes'
import { useReactFlow, Handle, Position, NodeToolbar } from '@xyflow/react'
import { get } from 'lodash'
import { useCallback } from 'react'

const NodeBox = styled(Box, {
  borderRadius: 12,
  boxShadow: '0 1px 4px 1px rgba(0, 0, 0, .08)',
  border: '1px solid #222',
  padding: 10,
})

export function NodeWithToolbar({ data, id, direction = 'LR' }) {
  const { screenToFlowPosition, getViewport } = useReactFlow()

  const onAdd = () => {
    //calcul la position du nouveau noeud au centre de l'ecran en fonction du viewport
    const viewport = getViewport()
    const centerPos = screenToFlowPosition({
      x: window.innerWidth / 2,
      y: window.innerHeight / 2,
    })

    const newNode = {
      id: getID(),
      type: NODE_TOOLBAR,
      position: { x: 0, y: 0 },
      data: { label: 'New node' },
      style: {},
    }

    const newEdge = {
      id: getID(),
      data: { label: 'New edge' },
      source: id,
      target: newNode.id,
    }

    $addNode(newNode)
    $addEdge(newEdge)
  }

  return (
    <NodeBox>
      <Handle
        type='target'
        position={direction === 'LR' ? Position.Left : Position.Top}
      />
      <Handle
        type='source'
        position={direction === 'LR' ? Position.Right : Position.Bottom}
      />
      <NodeToolbar
        isVisible={data.forceToolbarVisible || undefined}
        position={data.toolbarPosition}
        align={data.align}>
        <button
          className='xy-theme__button'
          onClick={onAdd}>
          add
        </button>
      </NodeToolbar>
      <div>{data?.label}</div>
    </NodeBox>
  )
}
