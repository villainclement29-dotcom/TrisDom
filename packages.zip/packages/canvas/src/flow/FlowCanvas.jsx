import { useState, useCallback, useMemo, useEffect } from 'react'
import {
  ReactFlow,
  Background,
  Controls,
  applyNodeChanges,
  applyEdgeChanges,
  addEdge,
  Position,
  MiniMap,
  Panel,
} from '@xyflow/react'
import '@xyflow/react/dist/style.css'
import { onAgent } from '@agentix/ai/src/actions/agent'
import dagre from '@dagrejs/dagre'
import { get } from 'lodash'
import { NodeWithToolbar } from './NodeWithToolbar'
import { useStore } from '@nanostores/react'
import { $edges, $nodes, $setEdges, $setNodes } from '@agentix/store'





const nodeTypes = {
  NodeWithToolbar: NodeWithToolbar,
}

export function FlowCanvas() {
  const [direction, setDirection] = useState('LR')

  const nodes = useStore($nodes)
  const edges = useStore($edges)

  const onNodesChange = useCallback((changes) => {
    const prev = $nodes.get()
    $setNodes(applyNodeChanges(changes, prev))
  }, [])

  const onEdgesChange = useCallback((changes) => {
    const prev = $edges.get()
    $setEdges(applyEdgeChanges(changes, prev))
  }, [])

  const onConnect = useCallback((params) => {
    const prev = $edges.get()
    $setEdges(addEdge(params, prev))
  }, [])

  return (
    <div style={{ width: '100vw', height: '100vh' }}>
      <ReactFlow
        nodes={nodes}
        edges={edges}
        nodeTypes={nodeTypes}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        fitView>
        <Background />
        <Panel>
          <button
            className='xy-theme__button'
            onClick={() => {
              setDirection('TB')
              const { nodes: n } = getLayoutedElements(nodes, edges, 'TB')
              setNodes(n)
            }}>
            Vertical
          </button>
          <button
            className='xy-theme__button'
            onClick={() => {
              setDirection('LR')
              const { nodes: n } = getLayoutedElements(nodes, edges, 'LR')
              setNodes(n)
            }}>
            Horizontal
          </button>
        </Panel>
        <MiniMap />
        <Controls />
      </ReactFlow>
    </div>
  )
}
