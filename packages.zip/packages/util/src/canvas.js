
export const NODE_WIDTH = 172
export const NODE_HEIGHT = 36
export const NODE_TOOLBAR = 'NodeWithToolbar'